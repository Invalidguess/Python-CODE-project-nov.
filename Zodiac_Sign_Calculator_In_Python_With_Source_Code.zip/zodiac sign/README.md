*****PYTHON TKINTER GUI PROJECTS*****


ZODIAC SIGN CALCULATOR : 

It calculates your Zodiac sign with input given as Date and Month. Have a look at the output.

!

